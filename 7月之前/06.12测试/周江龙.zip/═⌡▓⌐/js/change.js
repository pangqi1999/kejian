(
    function(){
        function change(){
            var root=1920;
            var pix=root/100;
            var view=document.documentElement.clientWidth||window.innerWidth;
            document.documentElement.style.fontSize=view/pix+"px";
        }
        
        window.document.addEventListener("DOMContentLoaded",change,false);
        window.addEventListener("resize",change,false);
    }
)()